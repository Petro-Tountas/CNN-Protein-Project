import torch
import torch.nn as nn

from model import ContactCNN
from dataset import sequence_to_pair_features, pdb_to_contact_map
from evaluate import precision_at_L5


def main():

    # -----------------------------
    # 1. DEFINE INPUT DATA
    # -----------------------------

    # Example protein: Crambin (1CRN)
    sequence = "TTCCPSIVARSNFNVCRLPGTPEAICATYTGCIIIPGATCPGDYAN"

    pdb_file = "example.pdb"  # Make sure this file exists in your folder

    print("Loading data...")

    # Convert sequence → input tensor (1, channels, N, N)
    x = sequence_to_pair_features(sequence).unsqueeze(0)

    # Convert PDB → ground truth contact map (1, 1, N, N)
    y = pdb_to_contact_map(pdb_file).unsqueeze(0)

    print("Input shape:", x.shape)
    print("Target shape:", y.shape)

    # -----------------------------
    # 2. INITIALIZE MODEL
    # -----------------------------

    model = ContactCNN()

    # Binary classification loss
    criterion = nn.BCELoss()

    # Optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # -----------------------------
    # 3. TRAINING LOOP
    # -----------------------------

    epochs = 50

    print("\nStarting training...\n")

    for epoch in range(epochs):

        # Forward pass
        prediction = model(x)

        # Compute loss
        loss = criterion(prediction, y)

        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Print progress
        if epoch % 5 == 0:
            print(f"Epoch {epoch}/{epochs} | Loss: {loss.item():.4f}")

    print("\nTraining complete.\n")

    # -----------------------------
    # 4. EVALUATION
    # -----------------------------

    precision = precision_at_L5(prediction[0][0], y[0][0])

    print("Final Results:")
    print("Precision @ L/5:", round(precision, 4))


if __name__ == "__main__":
    main()